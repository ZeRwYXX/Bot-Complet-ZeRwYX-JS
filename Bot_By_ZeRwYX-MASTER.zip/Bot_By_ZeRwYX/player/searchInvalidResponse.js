require('discord-reply');

module.exports = (client, message, query, tracks, content, collector) => {
    if (content === 'cancel') {
        collector.stop();
        return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> ${client.emotes.success} - La séléctin a été supprimer **cancelled** !`)
        .setColor('#9b9b9b'))
    } else message.lineReplyNoMention(new Discord.MessageEmbed()
    .setDescription(`<a:non:873277850520813618> ${client.emotes.error} - Nombre invalide**1** and **${tracks.length}** !`)
    .setColor('#9b9b9b'))
};