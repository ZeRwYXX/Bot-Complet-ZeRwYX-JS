require('discord-reply');
module.exports = (client, message, queue) => {
    message.lineReplyNoMention(new Discord.MessageEmbed()
    .setDescription(`<a:oui:873277851695206401> ${client.emotes.error} - La musique s'est arrêtée car il n'y a plus de membre dans le canal vocal !`)
    .setColor('#9b9b9b'))
};