require('discord-reply');

module.exports = (client, message, queue, track) => {
    message.lineReplyNoMention(new Discord.MessageEmbed()
    .setDescription(`<a:oui:873277851695206401>${client.emotes.music} - ${track.title} ajouté a la queue`)
    .setColor('#9b9b9b'))
};