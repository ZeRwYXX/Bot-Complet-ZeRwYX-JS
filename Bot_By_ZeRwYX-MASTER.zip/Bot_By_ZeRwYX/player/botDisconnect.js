require('discord-reply');
module.exports = (client, message, queue) => {
    message.lineReplyNoMention(new Discord.MessageEmbed()
    .setDescription(`<a:oui:873277851695206401> ${client.emotes.error} - La musique a été stoper avec succès!`)
    .setColor('#9b9b9b'))
};