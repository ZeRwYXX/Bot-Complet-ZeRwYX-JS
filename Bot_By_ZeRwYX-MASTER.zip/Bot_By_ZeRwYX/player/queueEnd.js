require('discord-reply');

module.exports = (client, message, queue) => {
    message.lineReplyNoMention(new Discord.MessageEmbed()
    .setDescription(`<a:oui:873277851695206401> ${client.emotes.error} - Je suis partit du vocal car j'avais plus de musique a vous chanté`)
    .setColor('#9b9b9b'))
};