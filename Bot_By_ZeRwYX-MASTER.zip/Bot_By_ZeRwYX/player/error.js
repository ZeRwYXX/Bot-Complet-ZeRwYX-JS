require('discord-reply');

module.exports = (client, error, message, ...args) => {
    switch (error) {
        case 'NotPlaying':
            message.lineReplyNoMention(new Discord.MessageEmbed()
            .setDescription(`<a:non:873277850520813618> ${client.emotes.error} - Il n'y a pas de musique en cours de lecture sur ce serveur`)
            .setColor('#9b9b9b'))
            break;
        case 'NotConnected':
            message.lineReplyNoMention(new Discord.MessageEmbed()
            .setDescription(`<a:non:873277850520813618> ${client.emotes.error} - Vous n'êtes connecté à aucun canal vocal `)
            .setColor('#9b9b9b'))
            break;
        case 'UnableToJoin':
            message.lineReplyNoMention(new Discord.MessageEmbed()
            .setDescription(`<a:non:873277850520813618> ${client.emotes.error} - Je n'arrive pas à rejoindre votre canal vocal, veuillez vérifier mes autorisations`)
            .setColor('#9b9b9b'))
            break;
        case 'VideoUnavailable':
            message.lineReplyNoMention(new Discord.MessageEmbed()
            .setDescription(`<a:non:873277850520813618> ${client.emotes.error} - ${args[0].title} n'est pas disponible dans votre pays`)
            .setColor('#9b9b9b'))
            break;
        case 'MusicStarting':
            message.lineReplyNoMention(new Discord.MessageEmbed()
            .setDescription(`<a:non:873277850520813618> La musique commence... veuillez patienter et réessayer !`)
            .setColor('#9b9b9b'))
            break;
        default:
            message.lineReplyNoMention(new Discord.MessageEmbed()
            .setDescription(`<a:non:873277850520813618> ${client.emotes.error} - Quelque chose s'est mal passé: ${error}`)
            .setColor('#9b9b9b'))
    };
};
