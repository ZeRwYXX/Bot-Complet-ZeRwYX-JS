require('discord-reply');

module.exports = (client, message, query) => {
    message.lineReplyNoMention(new Discord.MessageEmbed()
    .setDescription(`<a:non:873277850520813618> ${client.emotes.error} - Pas de résultats ${query} !`)
    .setColor('#9b9b9b'))
};