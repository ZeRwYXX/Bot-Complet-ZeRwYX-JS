require('discord-reply');

module.exports = (client, message, query, tracks) => {
    message.lineReplyNoMention(new Discord.MessageEmbed()
    .setDescription(`<a:oui:873277851695206401> ${client.emotes.error} - Recherche arréter`)
    .setColor('#9b9b9b'))
};