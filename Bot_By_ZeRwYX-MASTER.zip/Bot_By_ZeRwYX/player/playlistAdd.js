require('discord-reply');

module.exports = (client, message, queue, playlist) => {
    message.lineReplyNoMention(new Discord.MessageEmbed()
    .setDescription(`<a:oui:873277851695206401> ${client.emotes.music} - ${playlist.title} La playlist a été ajuter a la queu (**${playlist.tracks.length}**) !`)
    .setColor('#9b9b9b'))
};