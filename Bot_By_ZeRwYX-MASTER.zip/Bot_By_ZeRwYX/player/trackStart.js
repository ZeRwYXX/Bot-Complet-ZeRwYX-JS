require('discord-reply');

module.exports = (client, message, track, song) => {
    message.lineReplyNoMention(new Discord.MessageEmbed()
    .setTitle('🎶 Je commence à jouer')
    .addField('La Musique', `> [${track.title}](${track.url})`)
    .addField('Demander Par', `> ${message.member}`)
    .setColor('#9b9b9b'))
};