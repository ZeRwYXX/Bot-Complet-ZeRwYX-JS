require('discord-reply');

module.exports = (client, message, query, tracks) => {
    message.lineReplyNoMention({
        embed: {
            color: '#9b9b9b',
            author: { name: `Résultats de la recherche pour: ${query}` },
            timestamp: new Date(),
            description: `${tracks.map((t, i) => `**${i + 1}** - ${t.title}`).join('\n')}`,
        },
    });
};