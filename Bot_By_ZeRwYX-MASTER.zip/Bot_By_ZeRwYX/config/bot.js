
module.exports = {
    emojis: {
        off: '❗️',
        error: '<:fail:869983752556806144>',
        success: '<:success:869983752145735681>',
    },

    discord: {
        token: 'TOKEN',
        prefix: '$',
        inf: "ZeRwYXBot",
        db: 'mongodb+srv:',
    },

};
