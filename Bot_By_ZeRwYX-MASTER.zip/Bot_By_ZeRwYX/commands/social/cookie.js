const discord = require("discord.js");
require('discord-reply');
module.exports = {
  name: "cookie",
  category: "Social",
  utilisation: "Hug someone",
async execute(client, message, args1) {
    var rando_imgspat = [
    'https://assets.afcdn.com/recipe/20190529/93153_w1024h576c1cx2220cy1728.jpg',
    'https://img-3.journaldesfemmes.fr/_IQKLItHd4BWNdMh-03FtgI2ppM=/750x500/smart/b43857c04c9147e98997f9959bdd8f38/recipe-jdf/10027543.jpg',
    'https://img.cuisineaz.com/660x660/2015/08/11/i78773-cookie-moelleux-aux-pepites-de-chocolat.jpg',
    'https://www.papillesetpupilles.fr/wp-content/uploads/2005/07/Cookies-aux-pe%CC%81pites-de-chocolat-%C2%A9beats1.-shutterstock.jpg',
    'https://img.cuisineaz.com/660x660/2013/12/20/i6733-photo-de-cookies-aux-pepites-de-chocolat-laura-todd.jpeg',
    'https://freethepickle.fr/wp-content/uploads/2019/09/Cookies-6-of-8.jpg',
    'https://fac.img.pmdstatic.net/fit/http.3A.2F.2Fprd2-bone-image.2Es3-website-eu-west-1.2Eamazonaws.2Ecom.2Ffac.2F2020.2F04.2F27.2Fef91dd46-5287-4868-9387-83673eaa9924.2Ejpeg/1200x1200/quality/80/crop-from/center/tous-en-cuisine-la-recette-des-cookies-aux-deux-chocolats-de-cyril-lignac.jpeg'
];
var patfinal = rando_imgspat[Math.floor(Math.random() * rando_imgspat.length)];
if (!args1[0]) {
    const droit = new Discord.MessageEmbed()
    .setColor('#9b9b9b')
        .setDescription(`<a:uncheckmoove:740634696198914070> **Veuillez préciser à qui vous voulez donner un cookie**`);
    return message.lineReplyNoMention(droit);
}
const embedpat = new Discord.MessageEmbed()
.setColor('#9b9b9b')
    .setDescription(`:cookie: ${message.author.toString()} ` + ' give a cookie to ' + `**${args1}**`)
    .setImage(patfinal)
    .setTimestamp();
    message.lineReplyNoMention(embedpat);
}}