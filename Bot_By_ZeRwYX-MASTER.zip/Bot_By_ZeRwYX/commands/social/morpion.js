const Discord = require('discord.js');
const { MessageEmbed } = require('discord.js');
const morpion = require('morpionzerwyx');
const zerwyx = new morpion({ language: 'fr' })

module.exports = {
    name: 'morpion',
    aliases: [],
    category: 'Social',
    utilisation: '{prefix}morpion <@user>',
  
    execute(client, message, args) {
            zerwyx.handleMessage(message);
    }

    };