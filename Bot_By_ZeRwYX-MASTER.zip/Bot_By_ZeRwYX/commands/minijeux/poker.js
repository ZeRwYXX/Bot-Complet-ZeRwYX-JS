const {
    MessageEmbed,
    MessageAttachment
  } = require("discord.js");
  const fetch = require("node-fetch");
  module.exports = {
    name: "poker-night",
    aliases: ["pokernight", "poker"],
    category: 'Mini-Jeux',
    /*
755827207812677713 Poker Night
773336526917861400 Betrayal.io
832012586023256104 Chess
773336526917861400 End-Game
755600276941176913 YouTube Together
814288819477020702 Fishington.io
    */
async execute(client, message, args, cmduser, text, prefix) {
    try {
      const { channel } = message.member.voice;
      if (!channel) return message.channel.send(new MessageEmbed()
          .setColor("#9b9b9b")
          .setFooter("UnTi Tools")
          .setTitle("<:no:833101993668771842> Erreur | Veuillez d'abord rejoindre un salon vocal")
      );
      if (!channel.permissionsFor(message.guild.me).has("CREATE_INSTANT_INVITE")) {
        const nochannel = new MessageEmbed()
        .setDescription(`J'ai besoin de la permissions \`CREATE_INSTANT_INVITE\`!`)
        .setColor("#9b9b9b")
        .setFooter("UnTi Tools")
        return message.channel.send(nochannel);
      }
      await fetch(`https://discord.com/api/v8/channels/${channel.id}/invites`, {
          method: "POST",
          body: JSON.stringify({
              max_age: 86400,
              max_uses: 0,
              target_application_id: "755827207812677713", // youtube together
              target_type: 2,
              temporary: false,
              validate: null
          }),
          headers: {
              "Authorization": `Bot ODM3NjIwNTk2Nzc0MDEwODgw.YIvM-A.3gNtt6JNVSb2PrciIgDUSJdXzAw`,
              "Content-Type": "application/json"
          }
      }).then(res => res.json())
      .then(invite => {
          if (invite.error || !invite.code) {
              return message.channel.send(new MessageEmbed()
              .setDescription(`Impossible de démarrer Poker, veuillez réessayer`)
              .setColor("#9b9b9b")
              .setFooter("UnTi Tools"));
          }
          message.channel.send(`Cliquez sur le lien pour démarrer le JEU:\n> https://discord.com/invite/${invite.code}`);
      })
      } catch (e) {
          console.log(String(e.stack).bgRed)
          return message.channel.send(new Discord.MessageEmbed()
              .setColor("#9b9b9b")
              .setFooter("UnTi Tools")
              .setTitle(`<:no:833101993668771842> Une erreur s'est produite`)
              .setDescription(`\`\`\`${String(JSON.stringify(e)).substr(0, 2000)}\`\`\``)
          );
      }
  }
}