require('discord-reply');
module.exports = {
    name: 'play',
    aliases: ['p'],
    category: 'Music',
    utilisation: '{prefix}play [name/lien]',

    execute(client, message, args) {
        if (!message.member.voice.channel) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Tu n'est pas dans un salon vocal. !`)
        .setColor('#9b9b9b'))
        if (message.guild.me.voice.channel && message.member.voice.channel.id !== message.guild.me.voice.channel.id) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618>  - Je suis deja dans un salon vocal`)
        .setColor('#9b9b9b'))
        if (!args[0]) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Merci d'indiquer le son`)
        .setColor('#9b9b9b'))
        client.player.play(message, args.join(" "), { firstResult: true });
    },
};