require('discord-reply');
module.exports = {
    name: 'stop',
    aliases: ['dc'],
    category: 'Music',
    utilisation: '{prefix}stop',

    execute(client, message) {
        if (!message.member.voice.channel) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Tu n'est pas dans le salon vocal`)
        .setColor('#9b9b9b'))

        if (message.guild.me.voice.channel && message.member.voice.channel.id !== message.guild.me.voice.channel.id) return message.channel.send(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Je suis pas dans le même salon vocal que toi`)
        .setColor('#9b9b9b'))

        if (!client.player.getQueue(message)) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Aucune musique lancé`)
        .setColor('#9b9b9b'))

        client.player.setRepeatMode(message, false);
        const success = client.player.stop(message);

        if (success) message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:oui:873277851695206401> - La musique a été stoper`)
        .setColor('#9b9b9b'))
    },
};