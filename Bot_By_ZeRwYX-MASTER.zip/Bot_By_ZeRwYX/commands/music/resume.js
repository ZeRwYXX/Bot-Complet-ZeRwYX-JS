require('discord-reply');
module.exports = {
    name: 'resume',
    aliases: [],
    category: 'Music',
    utilisation: '{prefix}resume',

    execute(client, message) {
        if (!message.member.voice.channel) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Tu n'est pas dans le salon vocal`)
        .setColor('#9b9b9b'))

        if (message.guild.me.voice.channel && message.member.voice.channel.id !== message.guild.me.voice.channel.id) return message.lineReplyNoMention(`<a:non:873277850520813618> ${client.emotes.error} - You are not in the same voice channel !`);

        if (!client.player.getQueue(message)) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Aucune musique lancé`)
        .setColor('#9b9b9b'))

        if (!client.player.getQueue(message).paused) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - La musique rejoue déjà`)
        .setColor('#9b9b9b'))

        const success = client.player.resume(message);

        if (success) message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:oui:873277851695206401> - Song ${client.player.getQueue(message).playing.title} Résumer`)
        .setColor('#9b9b9b'))
    },
};