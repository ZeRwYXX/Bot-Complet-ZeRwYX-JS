require('discord-reply');
module.exports = {
    name: 'search',
    aliases: ['sr'],
    category: 'Music',
    utilisation: '{prefix}search [name/URL]',

    execute(client, message, args) {
        if (!message.member.voice.channel) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Tu n'est pas dans le salon vocal`)
        .setColor('#9b9b9b'))

        if (message.guild.me.voice.channel && message.member.voice.channel.id !== message.guild.me.voice.channel.id) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - You are not in the same voice channel !`)
        .setColor('#9b9b9b'))

        if (!args[0]) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Merci d'indiquer un son a cherché`)
        .setColor('#9b9b9b'))

        client.player.play(message, args.join(" "));
    },
};