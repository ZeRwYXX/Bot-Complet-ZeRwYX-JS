require('discord-reply');
module.exports = {
    name: 'queue',
    aliases: [],
    category: 'Music',
    utilisation: '{prefix}queue',

    execute(client, message, track) {
        if (!message.member.voice.channel) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Tu n'est pas dans le salon vocal`)
        .setColor('#9b9b9b'))

        if (message.guild.me.voice.channel && message.member.voice.channel.id !== message.guild.me.voice.channel.id) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Tu n'est pas dans le salon vocal!`)
        .setColor('#9b9b9b'))

        const queue = client.player.getQueue(message);

        if (!client.player.getQueue(message)) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Aucune musique lancé`)
        .setColor('#9b9b9b'))

        message.lineReplyNoMention(`**Queu: - ${message.guild.name} <:serveur:873870034110402590> ${client.player.getQueue(message).loopMode ? '(loop)' : ''}**\nActuel : ${queue.playing.title} | ${queue.playing.author}\n\n` + (queue.tracks.map((track, i) => {
            return `**#${i + 1}** - ${track.title} | ${track.author} (Demander par: ${track.requestedBy.username})`
        }).slice(0, 5).join('\n') + `\n\n${queue.tracks.length > 5 ? `Et **${queue.tracks.length - 5}** autres sons...` : `Dans la playlist**${queue.tracks.length}** son(s)`}`));
    },
};