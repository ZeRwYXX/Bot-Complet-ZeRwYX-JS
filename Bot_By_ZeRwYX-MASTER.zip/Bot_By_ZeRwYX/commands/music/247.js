const { MessageEmbed } = require("discord.js");
const fs = require('fs');


module.exports = {
    name: "afk",
    aliases: ["24/7"],

   async execute(client, message, args) {
    let afk = JSON.parse(fs.readFileSync("./afk.json", "utf8"));
    if(!message.member.hasPermission('MANAGE_SERVER'))return sendError("Vous n'êtes pas autorisé à utiliser cette commande", message.channel);
    if (!afk[message.guild.id]) afk[message.guild.id] = {
      afk: false,
    };
    var serverQueue = afk[message.guild.id]
    if (serverQueue) {

      serverQueue.afk = !serverQueue.afk;
      message.channel.send({
        embed: {
          color: "GREEN",
          description: `💤  **|**  AFK est **\`${serverQueue.afk === true ? "activé" : "désactivé"}\`**`
        }
      });
      return  fs.writeFile("./afk.json", JSON.stringify(afk), (err) => {
        if (err) console.error(err);
      });
    };
    return sendError("Il n'y a rien en jeu sur ce serveur.", message.channel);
  },
};