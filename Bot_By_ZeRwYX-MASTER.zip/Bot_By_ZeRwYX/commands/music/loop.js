require('discord-reply');
module.exports = {
    name: 'loop',
    aliases: ['lp', 'repeat'],
    category: 'Music',
    utilisation: '{prefix}loop',

    execute(client, message, args) {
        if (!message.member.voice.channel) return message.channel.send(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> -  Tu n'est pas dans un salon vocal.`)
        .setColor('#9b9b9b'))

        if (message.guild.me.voice.channel && message.member.voice.channel.id !== message.guild.me.voice.channel.id) return message.channel.send(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - You are not in the same voice channel !`)
        .setColor('#9b9b9b'))

        if (!client.player.getQueue(message)) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Pas de musique lancer`)
        .setColor('#9b9b9b'))

        if (args.join(" ").toLowerCase() === 'queue') {
            if (client.player.getQueue(message).loopMode) {
                client.player.setLoopMode(message, false);
                return message.lineReplyNoMention(new Discord.MessageEmbed()
                .setDescription(`<a:oui:873277851695206401> - Mode répétition **disabled** !`)
                .setColor('#9b9b9b'))
            } else {
                client.player.setLoopMode(message, true);
                return message.lineReplyNoMention(new Discord.MessageEmbed()
                .setDescription(`<a:oui:873277851695206401> - Mode répétition **enabled** toute la file d'attente sera répétée à l'infini`)
                .setColor('#9b9b9b'))
            };
        } else {
            if (client.player.getQueue(message).repeatMode) {
                client.player.setRepeatMode(message, false);
                return message.lineReplyNoMention(new Discord.MessageEmbed()
                .setDescription(`<a:oui:873277851695206401> - Mode répétition **disabled** !`)
                .setColor('#9b9b9b'))
            } else {
                client.player.setRepeatMode(message, true);
                return message.lineReplyNoMention(new Discord.MessageEmbed()
                .setDescription(`<a:oui:873277851695206401> - Mode répétition **enabled** the current music will be repeated endlessly !`)
                .setColor('#9b9b9b'))
            };
        };
    },
};