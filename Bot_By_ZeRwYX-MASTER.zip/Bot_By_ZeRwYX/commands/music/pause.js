require('discord-reply');
module.exports = {
    name: 'pause',
    aliases: [],
    category: 'Music',
    utilisation: '{prefix}pause',

    execute(client, message) {
        if (!message.member.voice.channel) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Tu n'est pas dans un salon vocal.`)
        .setColor('#9b9b9b'))

        if (message.guild.me.voice.channel && message.member.voice.channel.id !== message.guild.me.voice.channel.id) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - You are not in the same voice channel !`)
        .setColor('#9b9b9b'))

        if (!client.player.getQueue(message)) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Pas de musique lancer`)
        .setColor('#9b9b9b'))

        if (client.player.getQueue(message).paused) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - La musique et déjà en pause`)
        .setColor('#9b9b9b'))

        const success = client.player.pause(message);

        if (success) message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:oui:873277851695206401> - Son ${client.player.getQueue(message).playing.title} pause`)
        .setColor('#9b9b9b'))
    },
};