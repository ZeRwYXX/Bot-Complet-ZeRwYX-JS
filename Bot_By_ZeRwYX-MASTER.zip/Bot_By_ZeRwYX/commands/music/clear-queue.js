require('discord-reply');
module.exports = {
    name: 'clear-queue',
    aliases: ['cq'],
    category: 'Music',
    utilisation: '{prefix}clear-queue',

    execute(client, message) {
        if (!message.member.voice.channel) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Tu n'est pas dans le salon vocal`))

        if (message.guild.me.voice.channel && message.member.voice.channel.id !== message.guild.me.voice.channel.id) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - You are not in the same voice channel !`))

        if (!client.player.getQueue(message)) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Pas de musique lancé pour le moment`))

        if (client.player.getQueue(message).tracks.length <= 1) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Il n'y a qu'une seule chanson dans la file d'attente`))

        client.player.clearQueue(message);

        message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:oui:873277851695206401> - La queue a été supprimé !`))
    },
};