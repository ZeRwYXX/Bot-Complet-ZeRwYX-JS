require('discord-reply');
module.exports = {
    name: 'volume',
    aliases: [],
    category: 'Music',
    utilisation: '{prefix}volume [1-100]',

    execute(client, message, args) {
        if (!message.member.voice.channel) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Tu n'est pas dans le salon vocal`)
        .setColor('#9b9b9b'))

        if (message.guild.me.voice.channel && message.member.voice.channel.id !== message.guild.me.voice.channel.id) return message.channel.send(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Je suis pas dans le même salon vocal que toi`)
        .setColor('#9b9b9b'))

        if (!client.player.getQueue(message)) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - NAucune musique lancé`)
        .setColor('#9b9b9b'))

        if (!args[0] || isNaN(args[0]) || args[0] === 'Infinity') return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Merci d'entré un nombre valide.`)
        .setColor('#9b9b9b'))

        if (Math.round(parseInt(args[0])) < 1 || Math.round(parseInt(args[0])) > 100) return message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:non:873277850520813618> - Il me faut un nombre entre 1 et 100`)
        .setColor('#9b9b9b'))

        const success = client.player.setVolume(message, parseInt(args[0]));

        if (success) message.lineReplyNoMention(new Discord.MessageEmbed()
        .setDescription(`<a:oui:873277851695206401> - Volume à **${parseInt(args[0])}%** !`)
        .setColor('#9b9b9b'))
    },
};