const { MessageMenuOption, MessageMenu, MessageButton, MessageActionRow } = require("discord-buttons")
const { MessageEmbed } = require('discord.js');
require('discord-reply');

module.exports = {
    name: 'unity',
    aliases: ['unitybot', 'info', 'infos', 'invite', 'site', 'link'],
	category: 'Infos',
    utilisation: '{prefix}unity',
 execute( client, message, args) {
    const disbut = require("discord-buttons");
disbut(client);

		const sinfo_embed = new MessageEmbed()
		.setColor('#9b9b9b')
		.setTitle(`Informations | UnityBot`)
		.addField("<:developpeur:873869401311571988> Créateur du bot :", `≫ FlyHart`)
		.addField("<:pin:869999810944589845> Inviter le bot :", `≫ [Clique ici](https://discord.com/oauth2/authorize?client_id=684442905519325314&permissions=259077303511&scope=bot)`)
		.addField("<:stream:869983743618727966> Site Internet :", `≫ [Clique ici](https://genbot.fr)`)
        .setImage('https://images-ext-2.discordapp.net/external/JO_nd3UUugAthNvTVmwH17u1q7qvJx0WlY81gqJ_uEY/https/media.discordapp.net/attachments/873952650184507402/875668025758601236/UnTi_Tools_1.png')
		
        const button1 = new MessageButton()
        .setStyle('url')
        .setURL('https://discord.com/oauth2/authorize?client_id=684442905519325314&permissions=259077303511&scope=bot') 
        .setLabel('Invite le Bot'); 
        const button2 = new MessageButton()
        .setStyle('url')
        .setURL('https://genbot.fr') 
        .setLabel('Site Internet'); 
        message.lineReplyNoMention(sinfo_embed, button1, button2)
		console.log("command")
	}
}