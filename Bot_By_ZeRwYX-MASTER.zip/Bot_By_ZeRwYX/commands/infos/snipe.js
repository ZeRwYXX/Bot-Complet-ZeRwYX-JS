const discord = require("discord.js")
const config = require("../../config.json")
const db = require("quick.db")
require('discord-reply');
module.exports = {
        name: "snipe",
        utilisation: " ",
        category: "Infos",
     async execute(client, message, args) {

        const msg = client.snipes.get(message.channel.id)
        const embed = new Discord.MessageEmbed()
        .setAuthor(msg.author, msg.member.user.displayAvatarURL())
        .setDescription(msg.content)
        .setFooter('Hey j\'ai sniper ca')
        .setTimestamp();
        message.lineReplyNoMention(embed);
    }
    }
    

