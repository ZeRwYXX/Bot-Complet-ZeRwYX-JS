const db = require('quick.db');
require('discord-reply');
module.exports = {
        name: 'setxp',
        aliases: ['enablexp'],
        utilisation: ' ',
        category: 'Administration',
    async execute(client, message, args) {
        if (!message.member.hasPermission("ADMINISTRATOR")) return message.lineReplyNoMention("**<a:non:873277850520813618> Vous n'avez pas les autorisations requises ! - [ADMINISTRATOR]**")

        try {
            let a = await db.fetch(`guildMessages_${message.guild.id}`)

            if (a) {
                return message.lineReplyNoMention("**<a:non:873277850520813618> Les messages XP sont déjà activés sur le serveur!**")
            } else {
                db.set(`guildMessages_${message.guild.id}`, 1)

                message.lineReplyNoMention("**<a:oui:873277851695206401> Les messages XP sont activés avec succès !**")
            }
            return;
        } catch (e) {
            console.log(e)
            return message.lineReplyNoMention("**Quelque chose s'est mal passé!**")
        }
    }
}