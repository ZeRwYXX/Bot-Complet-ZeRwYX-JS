const db = require("quick.db");
require('discord-reply');
module.exports = {
    name: "setmuterole",
    aliases: ["setmute", "smrole", "smr"],
    utilisation: "[role name | role mention | role ID]",
    category: "Administration",
  async execute(client, message, args) {
    if (!message.member.hasPermission("ADMINISTRATOR"))
      return message.lineReplyNoMention(
        "**<a:non:873277850520813618> Vous n'avez pas les autorisations requises! - [ADMINISTRATOR]**"
      );
    if (!args[0]) {
      let b = await db.fetch(`muterole_${message.guild.id}`);
      let roleName = message.guild.roles.cache.get(b);
      if (message.guild.roles.cache.has(b)) {
        return message.lineReplyNoMention(
          `**<a:oui:873277851695206401> Muterole défini dans ce serveur est \`${roleName.name}\`!**`
        );
      } else
        return message.lineReplyNoMention(
          "**Veuillez saisir un nom de rôle ou un identifiant à définir !**"
        );
    }

    let role =
      message.mentions.roles.first() ||
      bot.guilds.cache.get(message.guild.id).roles.cache.get(args[0]) ||
      message.guild.roles.cache.find(
        c => c.name.toLowerCase() === args.join(" ").toLocaleLowerCase()
      );

    if (!role)
      return message.lineReplyNoMention("**<a:non:873277850520813618> Veuillez entrer un nom ou un identifiant de rôle valide!**");

    try {
      let a = await db.fetch(`muterole_${message.guild.id}`);

      if (role.id === a) {
        return message.lineReplyNoMention(
          "**<a:non:873277850520813618> Ce rôle est déjà défini comme Muterole!**"
        );
      } else {
        db.set(`muterole_${message.guild.id}`, role.id);

        message.lineReplyNoMention(
          `**<a:oui:873277851695206401> \`${role.name}\` A été défini avec succès comme Muterole!**`
        );
      }
    } catch (e) {
      return message.lineReplyNoMention(
        "**<a:non:873277850520813618> Erreur : `« Autorisations manquantes ou le rôle n'existe pas ! »`**",
        `\n${e.message}`
      );
    }
  }
};
