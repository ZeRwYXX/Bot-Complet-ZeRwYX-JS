const db = require('quick.db');
require('discord-reply');
module.exports = {
        name: "disablemuterole",
        aliases: ['clearmuterole', 'dmr', 'disablemr', 'dmrole'],
        utilisation: '[role name | role mention | role ID]',
        category: "Administration",
    async execute(client, message, args) {
        if (!message.member.hasPermission("ADMINISTRATOR")) return message.lineReplyNoMention("**<a:non:873277850520813618> Vous n'avez pas les autorisations requises! - [ADMINISTRATOR]**")

        try {
            let a = db.fetch(`muterole_${message.guild.id}`)

            if (!a) {
                return message.lineReplyNoMention("**<a:non:873277850520813618> Il n'y a pas de Muterole défini à désactiver!**")
            } else {
                let role = message.guild.roles.cache.get(a)
                db.delete(`muterole_${message.guild.id}`)

                message.lineReplyNoMention(`**<a:oui:873277851695206401> \`${role.name}\` A été désactivé avec succès**`)
            }
            return;
        } catch {
            return message.lineReplyNoMention("**<a:non:873277850520813618> Erreur : `« Autorisations manquantes ou le rôle n'existe pas`**")
        }
    }
}