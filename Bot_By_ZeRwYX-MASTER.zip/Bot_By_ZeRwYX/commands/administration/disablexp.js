const db = require('quick.db');
require('discord-reply');
module.exports = {
        name: 'disablexp',
        aliases: ['dxp'],
        category: 'Administration',
        utilisation: ' ',
    async execute(client, message, args) {
        if (!message.member.hasPermission("ADMINISTRATOR")) return message.lineReplyNoMention("**<a:non:873277850520813618> Vous n'avez pas les autorisations requises! - [ADMINISTRATOR]**")

        try {
            let a  = await db.fetch(`guildMessages_${message.guild.id}`)

            if (!a) {
                return message.lineReplyNoMention("**<a:non:873277850520813618> Les messages XP sont déjà désactivés sur le serveur !**")
            } else {
                db.delete(`guildMessages_${message.guild.id}`)

                message.lineReplyNoMention("**<a:oui:873277851695206401> Les messages XP sont désactivés avec succès !**")
            }
            return;
        } catch {
            return message.lineReplyNoMention("**<a:non:873277850520813618> Quelque chose s'est mal passé!**")
        }
    }
}