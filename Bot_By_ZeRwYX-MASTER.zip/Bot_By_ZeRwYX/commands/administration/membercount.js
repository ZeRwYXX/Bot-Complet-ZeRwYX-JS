require('discord-reply');
var Discord = require("discord.js");
const Enmap = require("enmap"); 
const srv = new Enmap({name: "serveur"}); 
module.exports = {
    name: "membercount",
    category: 'Administration',
    async execute(client, message, args) {(r => r.name == "@everyone");

    
    let bots = message.guild.members.cache.filter(mem => mem.user.bot === true).size
    let all = message.guild.memberCount
    let members = all-bots
    let everyone = message.guild.roles.cache.find(r => r.name == "@everyone");
    let category

        
            if(!message.member.hasPermission("ADMINISTRATOR")) {
                const droit = new Discord.MessageEmbed()
                    .setColor(client.config.red)
                    .setDescription("<a:non:873277850520813618> **Vous n'avez pas la permission de faire cette commande**");
                return message.lineReplyNoMention(droit);
            }
            if(!message.guild.member(client.user).hasPermission('ADMINISTRATOR')) {
                const droit = new Discord.MessageEmbed()
                    .setColor(client.config.red)
                    .setDescription(`<a:non:873277850520813618> **Je n'ai pas la permission de faire cela**`);
                return message.lineReplyNoMention(droit);
            }
            if(!args[1]){
                const droit = new Discord.MessageEmbed()
                    .setColor(client.config.red)
                    .setDescription(`<a:non:873277850520813618> **Veulliez préciser all/bots/members et ensuite on"**`);
                return message.lineReplyNoMention(droit);   
            }
        
            if(args[1] === "on"){
                
                if(srv.get(`${message.guild.id}` ,"membercount") === "on"){
                    const droit = new Discord.MessageEmbed()
                        .setColor(client.config.red)
                        .setDescription(`<a:non:873277850520813618> **Le compteur de membres est déjà activé**`);
                    return message.lineReplyNoMention(droit); 
                }
                srv.set(`${message.guild.id}`, "on", "membercount")
                message.guild.channels.create("Serveur Stats", {
                    type : "category"
                }).then((createChannel) => {
                    srv.set(createChannel.id,"Salons ") 
                    createChannel.overwritePermissions([
                        {
                            id: everyone.id,
                            deny: ["CONNECT"],
                        },
                    ], 'Needed to change permissions'); 
                    category = createChannel.id
                    createChannel.setPosition(1)
                })
                console.log(srv.get("Salons ") )
                message.guild.channels.create(srv.get("All Membres ")+": "+all, {
                    type: "voice"
                }).then((createChannel) => {
                    createChannel.setParent(category)
                    srv.set(`${message.guild.id}`, createChannel.id,"All Membres ")
                    console.log(srv.get("All Membres "))
                    createChannel.overwritePermissions([
                        {
                            id: everyone.id,
                            deny: ["CONNECT"],
                        },
                    ], 'Needed to change permissions'); 
                })
                
                message.guild.channels.create(srv.get("Bot ")+": "+bots, {
                    type: "voice"
                }).then((createChannel) => {
                    createChannel.setParent(category)
                    srv.set(`${message.guild.id}`, createChannel.id,"Bot")
                    console.log(srv.get("Bot"))
                    createChannel.overwritePermissions([
                        {
                            id: everyone.id,
                            deny: ["CONNECT"],
                        },
                    ], 'Needed to change permissions'); 
                })
                
                message.guild.channels.create(srv.get("Membres ")+": "+members, {
                    type: "voice"
                }).then((createChannel) => {
                    createChannel.setParent(category)
                    srv.set(`${message.guild.id}`, createChannel.id,"Membres ")
                    console.log(srv.get("Membres "))
                    createChannel.overwritePermissions([
                        {
                            id: everyone.id,
                            deny: ["CONNECT"],
                        },
                    ], 'Needed to change permissions'); 
                })
                
                
                  
            }else if(args[1] === "off"){
                if(srv.get(`${message.guild.id}` ,"membercount") === "off"){
                    const droit = new Discord.MessageEmbed()
                        .setColor(client.config.red)
                        .setDescription(`<a:uncheckmoove:740634696198914070> **Le compteur de membres est déjà désactivé**`);
                    return message.channel.send(droit); 
                }
                srv.set("off","membercount")
                const all = message.guild.channels.cache.get(srv.get("All Membres "));
                const bots = message.guild.channels.cache.get(srv.get("Bot "));
                const members = message.guild.channels.cache.get(srv.get("Membres "));
                const cat = message.guild.channels.cache.get(srv.get("Salons "));
                console.log(all)
                all.delete();
                members.delete();
                bots.delete();
                cat.delete();
            }else{
                const droit = new Discord.MessageEmbed()
                    .setColor(client.config.red)
                    .setDescription(`<a:uncheckmoove:740634696198914070> **Veulliez préciser on/off**`);
                return message.channel.send(droit);  
            }
        
        }
}