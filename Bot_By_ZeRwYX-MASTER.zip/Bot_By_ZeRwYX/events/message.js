module.exports = (client, message) => {
    
const Enmap = require("enmap");
const srv = new Enmap({name: "serveur"}); 

const LIMIT = 5;
const TIME = 30000;
const DIFF = 3000;  
if (message.author.bot) return;
if (message.channel.type === 'dm') return;


if(message.content.includes('ZeRwYX') || message.content.includes('ZeRwYX') || message.content.includes('<@683229702428819468>')){
  const droit = new Discord.MessageEmbed()
      .setColor('#5f5cff')
      .setFooter('© ZeRwYX 2021')
      .setDescription('<a:oui:873277851695206401> Mon nom est ZeRwYX. Fais ``$help`` pour obtenir la liste des commandes.');
  message.channel.send(droit);
}

const droit = "<a:uncheckmoove:740634696198914070> **Vous n'avez pas la permission de faire cela !**";
srv.ensure(`${message.guild.id}`, {
    guild: message.guild.id,
    rolemute: "none",
    catticket: "none",
    statimgwelc: "off",
    imgwelcchannel: "none",
    statimgleave : "off",
    imgleavechannel : "none",
    statwelc : "off",
    welcchannel : "none",
    statleave : "off",
    leavechannel : "none",
    autorole : "none",
    statautorole : "off",
    suggchannel: "none",
    statbadword: "off",
    statspam: "off",
    statreact: "off",
    logschannel: "none",
    statlogs: "off",
    antipub: "on",
    adchannel: "none",
    reportchannel: "none",
    modlogschannel: "none",
    ticketchannel: "none",
    membercounttextall: "Totale",
    membercounttextbots: "Bots",
    membercounttextmembers: "Membres",
    membercount: "off",
    membercountchannelall: "none",
    membercountchannelbots: "none",
    membercountchannelmembers: "none",
    membercountcat: "none",
    statlvl: "on",
    ticketrolestaff: "none",
});

   ////anti pub////

   if(srv.get(`${message.guild.id}`, "antipub") === "on"){
    if(!message.member.hasPermission("MANAGE_MESSAGES")){
      if(message.channel.id !== srv.get(`${message.guild.id}`, "adchannel").id){
        if(message.content.includes('discord.gg/') || message.content.includes('discordapp.com/invite/')) {
          message.delete();
          const droit = new Discord.MessageEmbed()
              .setDescription(`<a:uncheckmoove:740634696198914070> Désolé mais nous n'acceptons pas la pub ici ${message.author.username} \n\n > *Pour autoriser les pub faites la commande => $antipub off*`);
          return message.channel.send(droit);
        }
      }
    }

  }
    ////anti pub////

    ///anti spam////

    

    ////anti pub fin////

    const prefix = client.config.discord.prefix;

    if (message.content.indexOf(prefix) !== 0) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const command = args.shift().toLowerCase();

    const cmd = client.commands.get(command) || client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(command));

    if (cmd) cmd.execute(client, message, args);

};
