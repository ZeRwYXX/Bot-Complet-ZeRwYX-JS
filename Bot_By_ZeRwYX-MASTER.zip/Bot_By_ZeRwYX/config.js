exports.TOKEN = "TOKEN";

exports.DBL_API_KEY = "NONE";

exports.prefix = "$";

exports.GOOGLE_API_KEY = "";

exports.GENIUS_API_KEY = "";

exports.yandex_API = "";

exports.news_API = "";

exports.giphy_API = "";

exports.AME_API = "";

exports.blague_API = "";